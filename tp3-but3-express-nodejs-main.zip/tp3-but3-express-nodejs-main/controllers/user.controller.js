const getAllUsers = (res, req) => {
    req.status(500).json({
        status: 'error',
        message: 'This route is not yet implemented'
    })
}

const createUser = (res, req) => {
    req.status(500).json({
        status: 'error',
        message: 'This route is not yet implemented'
    })
}

const getUserById = (res, req) => {
    req.status(500).json({
        status: 'error',
        message: 'This route is not yet implemented'
    })
}

const updateUser = (res, req) => {
    req.status(500).json({
        status: 'error',
        message: 'This route is not yet implemented'
    })
}

export { getAllUsers, updateUser, createUser, getUserById }